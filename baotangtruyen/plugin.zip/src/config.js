let BASE_URL = "https://baotangtruyen32.top";
let BASE_API = "https://api.chilltruyentranh.site";

try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}