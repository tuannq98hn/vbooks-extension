let BASE_URL = "https://manhuavn.top";
let BASE_API = "https://mhvn.truyensieuhay.com";
let BASE_IMAGE = "https://admin.manhuavn.top/Pictures/Truyen/Large/";