function execute() {
    return Response.success([
        { title: "Cập Nhật", input: "2", script: "gen.js" },
        { title: "TOP Siêu Hay", input: "1", script: "gen.js" },
    ]);
}