function execute() {
    return Response.success([
        {title: "Mới Cập Nhật", input: "created_at", script: "gen.js"},
    ]);
}